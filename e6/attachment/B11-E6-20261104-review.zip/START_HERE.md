# B11 · E6 提交审阅包

本包由 E6 内容提交 `1e3a1012f9b82c9f89472324e47891dcb82a16ad` 导出，供课程检查与组内审阅使用。

- 分支：`feat/e6-submission`（本包固定提交 `1e3a1012f9b82c9f89472324e47891dcb82a16ad`）
- 仓库：https://git.nju.edu.cn/devops_b11/devops-project-b11

## 阅读顺序

1. `repository/e6/README.md` —— 入口与目录说明
2. `repository/e6/SUBMISSION.md` —— 提交说明与附件约定
3. `repository/e6/REPORT.md`、`REQUIREMENTS_CHECK.md` —— 实现报告与要求逐项核对
4. `repository/e6/EVIDENCE.md` —— 证据索引（含 `evidence/wang-shuo-20261103/`）
5. `repository/docs/e6/E6_B_241250110.md` —— 王硕 241250110 个人报告

## 复核（不重新构建）

```bash
cd repository
python3 e6/scripts/verify_archive.py
```

预期输出含 `passed: true`。该命令只校验归档记录，不把历史构建登记为新运行。

## 校验

`MANIFEST.json` 列出包内每个文件的 SHA-256 与固定提交；`B11-E6-20261104-review.zip.sha256` 给出压缩包整体摘要。
